
import torch
import config
from model import SpatioTemporalPricingCNN
import numpy as np

def the_predictor(model, data_batch):
    model.eval()
    with torch.no_grad():
        X = data_batch['X'].to(config.device)
        meta = data_batch['meta'].to(config.device)
        norm_tv = model(X, meta).cpu().numpy()
        spot = data_batch['spot'].numpy()
        intrinsic = data_batch['intrinsic'].numpy()
    return (norm_tv * spot) + intrinsic

def load_and_predict(path, sample):
    model = SpatioTemporalPricingCNN()
    model.load_state_dict(torch.load(path, map_location=config.device))
    model.to(config.device)
    # Wrap single sample in batch-like dict
    batch = {k: torch.tensor(v).unsqueeze(0) if not isinstance(v, torch.Tensor) else v.unsqueeze(0) for k, v in sample.items()}
    return the_predictor(model, batch)

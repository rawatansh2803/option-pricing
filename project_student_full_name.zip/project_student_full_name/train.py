
import torch
import torch.nn as nn
import torch.optim as optim
import config
from model import SpatioTemporalPricingCNN
from dataset import SyntheticDataGenerator, OptionDataset, prepare_tensors
import os
import numpy as np

def run_training():
    gen = SyntheticDataGenerator()
    und, opt = gen.generate()
    X, y, meta, spots, intrinsics = prepare_tensors(opt)
    
    # Save 10 artifacts for data/
    for i in range(10):
        np.save(f'data/img{i+1:02d}.npy', {'X': X[i], 'meta': meta[i], 'spot': spots[i], 'intrinsic': intrinsics[i], 'y': y[i]})
        
    ds = OptionDataset(X, y, meta, spots, intrinsics)
    loader = torch.utils.data.DataLoader(ds, batch_size=config.batch_size, shuffle=True)
    model = SpatioTemporalPricingCNN().to(config.device)
    opt_algo = optim.AdamW(model.parameters(), lr=config.learning_rate)
    crit = nn.MSELoss()
    
    model.train()
    for e in range(config.epochs):
        for b in loader:
            opt_algo.zero_grad()
            loss = crit(model(b['X'].to(config.device), b['meta'].to(config.device)), b['y'].to(config.device))
            loss.backward()
            opt_algo.step()
        if (e+1) % 5 == 0: print(f"Epoch {e+1} done.")
    torch.save(model.state_dict(), config.model_path)
    print("Training Complete.")

if __name__ == "__main__":
    run_training()
